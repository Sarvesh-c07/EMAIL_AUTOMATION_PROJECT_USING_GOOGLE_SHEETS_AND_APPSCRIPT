const APP_PASSWORD = "hariom00@";

function doGet(e) {
  const page = e && e.parameter && e.parameter.page;
  if (page === "app") {
    return HtmlService
      .createTemplateFromFile("Index")
      .evaluate()
      .setTitle("Email Automation Suite");
  }
  return HtmlService
    .createTemplateFromFile("Login")
    .evaluate()
    .setTitle("Email Automation Suite");
}

function include(filename) {
  return HtmlService
    .createHtmlOutputFromFile(filename)
    .getContent();
}

function getMainAppUrl() {
  return ScriptApp.getService().getUrl() + "?page=app";
}

function getLoggedInUser() {
  return Session.getActiveUser().getEmail();
}

/* ---------- SHEETS ---------- */
function getSheetNames() {
  const sheets =
    SpreadsheetApp.getActiveSpreadsheet()
    .getSheets();
  return sheets.map(sheet => sheet.getName());
}

/* ---------- DASHBOARD ---------- */
function getDashboardData(sheetName) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName(sheetName);
  if (!sheet) {
    throw new Error("Sheet not found");
  }
  const data = sheet.getDataRange().getValues();
  let sent = 0;
  let pending = 0;
  for (let i = 1; i < data.length; i++) {
    const status = String(data[i][2]).trim().toLowerCase();
    if (status === "sent") {
      sent++;
    } else {
      pending++;
    }
  }
  return {
    sent,
    pending,
    total: Math.max(data.length - 1, 0)
  };
}

/* ---------- RECIPIENTS ---------- */
function getRecipients(sheetName) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName(sheetName);
  if (!sheet) {
    throw new Error("Sheet not found");
  }
  const data = sheet.getDataRange().getValues();
  let recipients = [];
  for (let i = 1; i < data.length; i++) {
    recipients.push({
      row: i + 1,
      name: data[i][0],
      email: data[i][1],
      status: data[i][2] || "Pending"
    });
  }
  return recipients;
}

/* ---------- SIMULATION ---------- */
function simulateCampaign(sheetName) {
  const sender = Session.getActiveUser().getEmail();
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName(sheetName);
  const data = sheet.getDataRange().getValues();
  let pending = 0;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][2]).toLowerCase() !== "sent") {
      pending++;
    }
  }
  return {
    sender,
    recipients: pending,
    sheet: sheetName,
    message: "Simulation Successful. No emails were sent."
  };
}

/* ---------- SEND EMAILS ---------- */
function sendEmails(password, sheetName) {
  if (password !== APP_PASSWORD) {
    throw new Error("ACCESS DENIED - Incorrect Password");
  }
  const sender = Session.getActiveUser().getEmail();
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName(sheetName);
  const data = sheet.getDataRange().getValues();
  let sentCount = 0;
  for (let i = 1; i < data.length; i++) {
    const name = data[i][0];
    const email = data[i][1];
    const status = String(data[i][2]).toLowerCase();
    if (status === "sent") {
      continue;
    }
  const htmlBody = `
  <div style="font-family:Segoe UI,Arial,sans-serif;padding:25px;line-height:1.8;color:#333;">
    <p>To ${name},</p>
    <p>We request you to kindly provide the Ledger Statement for FY 2025-26 or a bill-wise Balance Confirmation as on 31.03.2026.</p>
    <p>
      The same is required for our audit and account reconciliation purposes.
    </p>
    <p>
      We would appreciate your early response and request you to share the details at your earliest convenience.
    </p>
    <p>
      Thank you for your cooperation.
    </p>
    <br>
    <p>Thanks & Regards,</p>
    <p>
      <strong>3S PHARMACEUTICALS INDIA PRIVATE LIMITED</strong><br>
      <strong>Mamta Vandra</strong><br>
      <strong>Accounts Department</strong><br>
      ${"3sindiapltd@gmail.com"}
    </p>
  </div>
`;
    GmailApp.sendEmail(
      email,
      "Re: Balance Confirmation as on 31st March 2026",
      "",
      {
        htmlBody,
        name: "3S PHARMACEUTICALS INDIA PRIVATE LIMITED"
      }
    );
    sheet.getRange(i + 1, 3).setValue("Sent");
    sheet.getRange(i + 1, 4).setValue(new Date());
    sentCount++;
  }
  return sentCount + " emails sent successfully from sheet: " + sheetName;
}
